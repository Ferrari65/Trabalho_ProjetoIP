const express = require('express');
const app = express();
const path = require('path');

// Middleware para processar dados de formulários
app.use(express.urlencoded({ extended: true })); // Para processar dados enviados via POST

// Configuração da pasta para arquivos estáticos (CSS, imagens, JS)
app.use(express.static(path.join(__dirname, 'public')));

// Configuração  de visualização
app.set('view engine', 'ejs');

// Rota para a página inicial
app.get('/', (req, res) => {
    res.render('telainicial'); // Renderiza a página inicial
});

// Rota para a página de cadastro
app.get('/cadastro', (req, res) => {
    res.render('cadastro'); // Renderiza a página de cadastro
});

// Rota para processar o formulário de cadastro
app.post('/cadastro', (req, res) => {
    const { nome, email, matricula, senha, confirmarSenha } = req.body;

    // Verifica se as senhas coincidem
    if (senha !== confirmarSenha) {
        return res.redirect('/cadastro'); // Redireciona de volta ao cadastro
    }

    // Simulação de salvamento no banco de dados
    console.log('Dados recebidos:', { nome, email, matricula, senha });

    // Após salvar os dados com sucesso, redirecionar para a tela de login
    res.redirect('/Login');
});

// Rota para a página de login
app.get('/Login', (req, res) => {
    res.render('login'); 
});

// Rota para processar o login
app.post('/login', (req, res) => {
    res.redirect('/listaIP');
});

// Rota para a página listaIP 
app.get('/listaIP', (req, res) => {
    res.render('listaIP');  
});

// Inicializa o servidor
app.listen(3001, () => {
    console.log('Servidor rodando na porta 3001');
});
